=== Group Thrpy ===
Contributors: dcmanagertech1121
Requires at least: 5.3
Tested up to: 5.8
Requires PHP: 5.6
Stable tag: 1.4
License: GPLv2 or later
License URI: 

== Description ==

Group Thrpy theme is a blank canvas for your ideas and it makes the block editor your best brush.

With new block patterns, which allow you to create a beautiful layout in a matter of seconds, this theme’s soft colors and eye-catching — yet timeless — design will let your work shine.

Take it for a spin! See how Group Thrpy elevates your portfolio, business website, or personal blog.


